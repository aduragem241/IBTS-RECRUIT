import type { Metadata } from 'next';import './globals.css';import {Shell} from '@/components/Shell';
export const metadata:Metadata={title:'IBTS RECRUIT | Careers & Opportunities',description:'Explore career pathways and recruitment information with IBTS RECRUIT.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en" suppressHydrationWarning><body><Shell>{children}</Shell></body></html>};
