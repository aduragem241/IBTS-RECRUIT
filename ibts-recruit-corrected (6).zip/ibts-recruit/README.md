# IBTS RECRUIT — Next.js Starter

This is the **IBTS RECRUIT** website starter. It is an **honest implementation starter**, not a deployed production system. It includes a responsive visual website, 25 job **categories**, digital tool directory, six language labels, system/light/dark modes, policy drafts, cookie preferences and basic Supabase email/password registration UI. It deliberately does **not** fabricate open jobs, partnerships, prices, payments, applicant records, AI results or testimonials.

## Run

```bash
npm install
cp .env.example .env.local
npm run dev
```

Configure a real Supabase project and apply the SQL schema with careful review. The registration UI only works with configured Supabase Auth. Configure email verification and the correct callback settings in the Supabase dashboard. Existing pages `/dashboard` and `/admin` are safe placeholders, **not** finished workflows. The digital-tools and reviews sections are intentionally kept out of the public navigation until authorised distribution and approved testimonials are ready. The marketplace never initiates payment.

## What remains before production

- Configure Supabase auth, roles, triggers, private CV storage, permissions, registration profile persistence, user verification and secure SSR sessions.
- Implement role-based admin UI and API, 13 real modules, actual verified job publishing and real applicant state transitions.
- Implement assessment authoring, timer, server autosave, AI provider configuration and human-controlled grading.
- Implement authorized marketplace suppliers, configured NGN rates, cart, orders, server payment initialization, Paystack/Flutterwave verification + event ledger + idempotent fulfillment, PDF receipts.
- Implement Resend notifications, email verification and audit trails, data exports and reporting.
- Complete localisation of ALL page copy (currently the navbar and account controls switch language), accessibility/RTL QA and full automated tests.
- Obtain confirmed legal/company information, review policies and secure independent penetration testing.
- Deploy to Vercel after reviewing secrets, runtime behavior and production safeguards.

**Never publish seed categories as live vacancies without approval. Never activate third-party sales without reseller authorization.**
