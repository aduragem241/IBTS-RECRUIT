-- IBTS RECRUIT database foundation. Review and test in nonproduction before applying.
create extension if not exists pgcrypto;
create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 first_name text not null default '', last_name text not null default '',
 phone text, country text, referral_source text, referral_details text,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.staff_roles (
 user_id uuid primary key references auth.users(id) on delete cascade,
 role text not null check(role in ('admin','recruiter','finance','content')),
 granted_at timestamptz not null default now()
);
create table if not exists public.jobs (
 id uuid primary key default gen_random_uuid(), slug text unique not null,
 title text not null, department text, description text, responsibilities text,
 skills text, qualifications text, experience text,
 employment_type text, workplace_type text, location text,
 compensation_min_kobo bigint, compensation_max_kobo bigint,
 deadline timestamptz, status text not null default 'draft' check(status in ('draft','active','closed')),
 created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
 check(compensation_min_kobo is null or compensation_min_kobo >= 0),
 check(compensation_max_kobo is null or compensation_min_kobo is null or compensation_max_kobo >= compensation_min_kobo)
);
-- Serialize active publication transactions, enforcing strict 25-active hard limit.
create or replace function public.enforce_active_jobs_cap() returns trigger language plpgsql set search_path = '' as $$
begin
 if new.status = 'active' and (tg_op = 'INSERT' or old.status is distinct from 'active') then
  perform pg_catalog.pg_advisory_xact_lock(2683144);
  if (select count(*) from public.jobs where status='active') >= 25 then
   raise exception 'No more than 25 active job openings are allowed';
  end if;
 end if;
 return new;
end;$$;
drop trigger if exists active_job_limit on public.jobs;
create trigger active_job_limit before insert or update of status on public.jobs
 for each row execute function public.enforce_active_jobs_cap();
create table if not exists public.applications (
 id uuid primary key default gen_random_uuid(), job_id uuid not null references public.jobs(id),
 applicant_id uuid not null references auth.users(id),
 cv_path text, cover_letter text,
 status text not null default 'submitted' check(status in
 ('submitted','under_review','shortlisted','assessment_pending','assessment_completed','interview_stage','selected','not_selected')),
 created_at timestamptz not null default now(),updated_at timestamptz not null default now(),
 unique(job_id,applicant_id)
);
create table if not exists public.assessments (
 id uuid primary key default gen_random_uuid(), job_id uuid not null references public.jobs(id),
 title text not null, duration_minutes integer not null check(duration_minutes between 1 and 240),
 rubric jsonb not null default '{}'::jsonb, status text not null default 'draft'
 check(status in ('draft','ready','closed')),
 created_at timestamptz not null default now()
);
create table if not exists public.assessment_questions (
 id uuid primary key default gen_random_uuid(), assessment_id uuid not null references public.assessments(id) on delete cascade,
 ordinal integer not null, format text not null check(format in ('mcq','written','technical','situational','timed')),
 prompt text not null, options jsonb, correct_answer jsonb, rubric jsonb,
 unique(assessment_id,ordinal)
);
create table if not exists public.assessment_attempts (
 id uuid primary key default gen_random_uuid(), assessment_id uuid not null references public.assessments(id),
 application_id uuid not null references public.applications(id),
 started_at timestamptz not null default now(), deadline_at timestamptz not null,
 submitted_at timestamptz, answers jsonb not null default '{}'::jsonb,
 objective_score numeric, review_notes text, reviewed_by uuid references auth.users(id),
 unique(assessment_id,application_id)
);
create table if not exists public.products (
 id uuid primary key default gen_random_uuid(), name text not null, slug text unique not null,
 description text, vendor text, reseller_verified boolean not null default false,
 available boolean not null default false, created_at timestamptz not null default now(),
 check(not available or reseller_verified)
);
create table if not exists public.product_tiers (
 id uuid primary key default gen_random_uuid(), product_id uuid not null references public.products(id) on delete cascade,
 tier text not null check(tier in ('monthly','quarterly','six_months','annual')),
 price_kobo bigint not null check(price_kobo > 0), active boolean not null default false,
 unique(product_id,tier)
);
create table if not exists public.orders (
 id uuid primary key default gen_random_uuid(), customer_id uuid not null references auth.users(id),
 status text not null default 'pending' check(status in ('pending','successful','failed','refunded')),
 total_kobo bigint not null check(total_kobo > 0), currency char(3) not null default 'NGN',
 created_at timestamptz not null default now()
);
create table if not exists public.order_items (
 id uuid primary key default gen_random_uuid(), order_id uuid not null references public.orders(id) on delete cascade,
 tier_id uuid not null references public.product_tiers(id), price_kobo bigint not null check(price_kobo > 0)
);
create table if not exists public.payments (
 id uuid primary key default gen_random_uuid(), order_id uuid not null references public.orders(id),
 provider text not null check(provider in ('paystack','flutterwave')),
 reference text not null unique,
 provider_transaction_id text,
 status text not null default 'pending' check(status in ('pending','successful','failed','refunded')),
 amount_kobo bigint not null check(amount_kobo > 0),
 created_at timestamptz not null default now(), confirmed_at timestamptz,
 unique(provider,provider_transaction_id)
);
create table if not exists public.payment_events (
 id uuid primary key default gen_random_uuid(), provider text not null,
 event_identity text not null, reference text,
 payload jsonb not null, verified_at timestamptz not null default now(),
 unique(provider,event_identity)
);
create table if not exists public.reviews (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id),
 display_name text not null, rating integer not null check(rating between 1 and 5),
 comment text not null, moderation_status text not null default 'pending'
 check(moderation_status in ('pending','approved','rejected')),
 created_at timestamptz not null default now()
);
create table if not exists public.notifications (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id),
 title text not null, body text not null, read_at timestamptz, created_at timestamptz not null default now()
);
create table if not exists public.audit_logs (
 id bigint generated always as identity primary key,
 actor_id uuid references auth.users(id), action text not null, object_type text not null,
 object_id text, metadata jsonb not null default '{}'::jsonb,
 created_at timestamptz not null default now()
);
-- All tables in exposed public schema have RLS enabled; unlisted permissions DENY.
alter table public.profiles enable row level security;
alter table public.staff_roles enable row level security;
alter table public.jobs enable row level security;
alter table public.applications enable row level security;
alter table public.assessments enable row level security;
alter table public.assessment_questions enable row level security;
alter table public.assessment_attempts enable row level security;
alter table public.products enable row level security;
alter table public.product_tiers enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.payments enable row level security;
alter table public.payment_events enable row level security;
alter table public.reviews enable row level security;
alter table public.notifications enable row level security;
alter table public.audit_logs enable row level security;
create policy "profile self read" on public.profiles for select to authenticated using ((select auth.uid()) = id);
create policy "profile self insert" on public.profiles for insert to authenticated with check ((select auth.uid()) = id);
create policy "profile self edit" on public.profiles for update to authenticated using ((select auth.uid())=id) with check ((select auth.uid())=id);
create policy "public active jobs" on public.jobs for select to anon,authenticated using (status='active');
create policy "public live products" on public.products for select to anon,authenticated using (available and reseller_verified);
create policy "public active tiers" on public.product_tiers for select to anon,authenticated using(active and exists(select 1 from public.products p where p.id=product_id and p.available and p.reseller_verified));
create policy "public approved reviews" on public.reviews for select to anon,authenticated using(moderation_status='approved');
create policy "own reviews read" on public.reviews for select to authenticated using((select auth.uid())=user_id);
create policy "own review submit" on public.reviews for insert to authenticated with check ((select auth.uid())=user_id and moderation_status='pending');
create policy "own application read" on public.applications for select to authenticated using((select auth.uid())=applicant_id);
create policy "own application submit" on public.applications for insert to authenticated with check((select auth.uid())=applicant_id and status='submitted' and exists(select 1 from public.jobs j where j.id=job_id and j.status='active' and (j.deadline is null or j.deadline>now())));
create policy "own orders read" on public.orders for select to authenticated using((select auth.uid())=customer_id);
create policy "own order items read" on public.order_items for select to authenticated using(exists(select 1 from public.orders o where o.id=order_id and o.customer_id=(select auth.uid())));
create policy "own payments read" on public.payments for select to authenticated using(exists(select 1 from public.orders o where o.id=order_id and o.customer_id=(select auth.uid())));
create policy "own notification read" on public.notifications for select to authenticated using((select auth.uid())=user_id);
create policy "own notification edit" on public.notifications for update to authenticated using((select auth.uid())=user_id) with check((select auth.uid())=user_id);
-- Admin/staff mutations and payment transitions MUST occur through privileged server
-- methods with independently checked roles, never through direct browser writes.
-- No SELECT policy for staff_roles, audit_logs, payment_events or secret exam answers.
-- Direct database client access does not confer admin privileges.
